import { Link } from "react-router-dom";
export default function Navbar() {
  const isLoggedIn = !!localStorage.getItem("token");
  return (
    <nav className="bg-gray-800 text-white p-4 flex justify-between">
      <div className="font-bold">MiniLinkedIn</div>
      <div className="space-x-4">
        <Link to="/">Home</Link>
        {!isLoggedIn && <Link to="/login">Login</Link>}
        {!isLoggedIn && <Link to="/register">Register</Link>}
        {isLoggedIn && <button onClick={() => { localStorage.removeItem("token"); window.location.reload(); }}>Logout</button>}
      </div>
    </nav>
  );
}
