const router = require('express').Router();
const User = require('../models/User');
const Post = require('../models/Post');

router.get('/:id', async (req, res) => {
  const user = await User.findById(req.params.id);
  const posts = await Post.find({ authorId: user._id }).sort({ createdAt: -1 });
  res.json({ user, posts });
});

module.exports = router;
