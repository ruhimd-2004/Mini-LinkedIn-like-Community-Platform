const router = require('express').Router();
const jwt = require('jsonwebtoken');
const Post = require('../models/Post');

const auth = (req, res, next) => {
  const token = req.headers.authorization;
  if (!token) return res.sendStatus(401);
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    res.sendStatus(401);
  }
};

router.get('/', async (req, res) => {
  const posts = await Post.find().populate('authorId', 'name').sort({ createdAt: -1 });
  res.json(posts);
});

router.post('/', auth, async (req, res) => {
  const post = new Post({ text: req.body.text, authorId: req.user.id });
  await post.save();
  res.status(201).json(post);
});

module.exports = router;
